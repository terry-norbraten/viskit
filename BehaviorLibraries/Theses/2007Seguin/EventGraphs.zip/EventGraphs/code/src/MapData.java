/*
 * MapData.java
 *
 * Created on November 10, 2006, 1:45 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package seadiver;

import java.util.HashMap;

/**
 *
 * @author John Seguin
 */
public class MapData extends HashMap {

    /** Creates a new instance of MapData */
    public MapData() {
    }

}
